-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Ноя 28 2022 г., 13:30
-- Версия сервера: 10.4.25-MariaDB
-- Версия PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `quiz`
--

-- --------------------------------------------------------

--
-- Структура таблицы `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `password` varchar(10) NOT NULL,
  `totalPreguntas` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `config`
--

INSERT INTO `config` (`id`, `usuario`, `password`, `totalPreguntas`) VALUES
(1, 'admin', 'admin', 10);

-- --------------------------------------------------------

--
-- Структура таблицы `estadisticas`
--

CREATE TABLE `estadisticas` (
  `id` int(11) NOT NULL,
  `visitas` int(11) NOT NULL,
  `respondidas` int(11) NOT NULL,
  `completados` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `estadisticas`
--

INSERT INTO `estadisticas` (`id`, `visitas`, `respondidas`, `completados`) VALUES
(1, 2, 0, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `preguntas`
--

CREATE TABLE `preguntas` (
  `id` int(11) NOT NULL,
  `tema` int(11) NOT NULL,
  `pregunta` text NOT NULL,
  `opcion_a` text NOT NULL,
  `opcion_b` text NOT NULL,
  `opcion_c` text NOT NULL,
  `correcta` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `preguntas`
--

INSERT INTO `preguntas` (`id`, `tema`, `pregunta`, `opcion_a`, `opcion_b`, `opcion_c`, `correcta`) VALUES
(1, 1, 'The definition of algorithm is...', 'A type of computer code', 'A sequence of instructions that\nrepresent a solution model for certain types of problems, including all the necessary steps.', 'A\nprogramming language', 'B'),
(2, 1, 'What is C++?', 'A game', 'A program', 'A programming language', 'C'),
(3, 1, 'What is a variable?', 'A value or data', 'A space within the ram space', 'A language', 'B'),
(4, 1, 'In javascript, the for statement is used to', 'Repeat the execution of instructions', 'Load data\ninto an array', 'None of the above', 'A'),
(5, 1, 'In a programming language the constants are...', 'Data that varies', 'Regular data', 'Data that\ndoes not change in the process', 'C'),
(6, 1, 'A flowchart is...', 'the way to solve a problem', 'The graphical representation of a problem', 'The\nprocess of designing an algorithm', 'B'),
(7, 1, 'What kind of data is example A=5?', 'char', 'integer', 'string', 'B'),
(8, 1, 'What is the use of general-purpose programming languages?', 'Create and provide data', 'Create different mechanisms', 'Create different types of applications', 'C'),
(9, 1, 'The number in binary 1010 corresponds', '10 in decimal', '8 in decimal', '7 in decimal', 'A'),
(10, 1, 'An \"array\" is...', ' A structured data type that stores data, of the same type and related.', 'A\nstructure that allows me to repeat instructions as many times as I want', 'None of the above', 'A'),
(11, 2, 'By what name is the scandal that forced US President Richard Nixon to resign known?', 'Vietnam', 'NixonPrecess', 'Watergate', 'C'),
(12, 2, 'Which Roman emperor legalized Christianity and put an end to the persecution of\nChristians?', 'Nero', 'Constanstine', 'Hadrian', 'B'),
(13, 2, 'Which computing milestone of 1969 would radically change the course of human history?', 'The first wi-fi router', 'The first personal computer', 'Internet', 'C'),
(14, 2, 'Who was the first President of the United States?', 'George Washington', 'Abraham Lincoln', 'Andrew Jackson', 'A'),
(15, 2, 'Why is the Poem of Gilgamesh significant?', 'It was a 500-page military strategy book that\nserved in ancient Mesopotamia', 'It is the first epic work that makes reference to immortality and\nthe human perception of the soul', 'The oldest extant treatise on the Underworld.', 'B'),
(16, 2, 'What is the name of the famous battle where Napoleon Bonaparte was defeated?', 'The\nBattle of Hastings', 'The Battle of Alamo', 'The Battle of Waterloo', 'C'),
(17, 2, 'Through which African river did ancient Egypt rise?', 'Amazon', 'Tigris', 'Nile', 'C'),
(18, 2, 'To which Greek philosopher is the famous work “The Republic\" attributed?', 'Plato', 'Socrates', 'Aristotle', 'A'),
(19, 2, 'In what year was the Soviet Union dissolved?', 'In 1987', 'In 1989', 'In 1991', 'C'),
(20, 2, 'Which scientist is considered the Father of the Atomic Bomb?', 'Albert Einstein', 'Robert\nOpenheimer', 'Leó Szilárd', 'B'),
(21, 3, 'What do the chloroplasts of plant cells contain?', 'Chlorophyll', 'Water', 'Aloe', 'A'),
(22, 3, 'What is malacology?', 'The science that studies fungi', 'The science that studies molluscs', 'The science that studies mites', 'B'),
(23, 3, 'What do the acronyms DNA mean?', 'Deoxynucleic acid', 'deoribonucleic acid', 'Deoxyribonucleic acid', 'C'),
(24, 3, 'All organisms in the kingdom Animalia are:', 'Multicellular and autotrophs', 'Multicellular and\nautotrophs', 'Unicellular and heterotrophs', 'B'),
(25, 3, 'What is a shoal?', 'A kind of plant', 'A school of fish', 'A part of the abdomen of insects', 'B'),
(26, 3, 'The current taxonomic classification system was devised by:', 'Darwin', 'Pateur', 'Linnaeus', 'B'),
(27, 3, 'Which of the following animals has incisors that continue to grow all their lives?', 'Walrus', 'Hamster', 'Elephant', 'B'),
(28, 3, 'How long does a hedgehog live?', 'Approximately between 4 and 5 years', 'Approximately\nbetween 7 and 8 years', 'Approximately between 9 and 12 years', 'A'),
(29, 3, 'Where do plants carry out photosynthesis?', 'In the leaves', 'At the root', 'In the air', 'A'),
(30, 3, 'Which muscle drives the blood throughout our body?', 'The brain', 'The lungs', 'The heart', 'C'),
(31, 4, 'What is a direct serve point called in tennis?', 'Reverse', 'Love', 'Ace', 'C'),
(32, 4, 'In swimming, how long is a competition pool for Olympics and world championships?', '50\nmeters', '25 meters', '30 meters', 'A'),
(33, 4, 'How many track players does a volleyball team play with?', '5', '9', '6', ' '),
(34, 4, 'What is it called in golf when you complete a hole on one shot less than the par of the\nhole?', 'Albatross', 'Birdie', 'Eagle', 'B'),
(35, 4, 'The three modes of fencing are: saber, sword and...', 'Rapier', 'Foil', 'lbre Style', 'B'),
(36, 4, 'What is it called in baseball when a batter hits the ball and it goes out of the field of play,\nallowing him to go around all the bases with ease?', 'Strike', 'Hit', 'Home run', 'C'),
(37, 4, 'How far is the penalty spot from the goal in football?', '7 meters', '11 meters', '12 meters', 'B'),
(38, 4, 'Complete this basketball sentence: &quot; The referee bleeped _____ seconds in the zone\nand the home team lost the ball&quot; ', 'Five', 'Twenty-four', 'Three', 'C'),
(39, 4, 'If we talk about the buoy player, we are talking about...', 'Volleyball', 'Roller hockey', 'Water\nPolo', 'C'),
(40, 4, 'What do you call in rugby the head-to-head struggle of two groups of players from the two\nteams pushing to get the ball without touching it with their hand?', 'Tackle', 'Scrum', 'Rehearsal', 'B'),
(41, 5, 'A little history. What Greek sage believed that the only basic law governing the universe was\nthe principle of change and that nothing remained in the same state indefinitely?', 'Tales of Miletus', 'Heraclitus', 'Aristotle', 'B'),
(42, 5, 'The scientific method is used in all sciences, including physics and psychology.', 'True', 'False, in physics no', 'None of the above', 'A'),
(43, 5, 'What is the name of the instrument that measures and records the relative humidity of the\nair?', 'Barometer', 'Hydrometer', 'Hygrometer', 'C'),
(44, 5, 'Every body that falls freely into the void is characterized by having...', 'Constant acceleration\nand variable speed', 'Variable force and decreasing speed', 'Constant potential energy and\nincreasing acceleration', 'B'),
(45, 5, 'Speaking of forces... what holds the molecules of a body together?', 'The force of gravity', 'The cohesive force', 'The adhesion force', 'B'),
(46, 5, 'What is the smallest possible distance in quantum mechanics?', 'Wearden time', 'Quantum\nfoam', 'Planck Length', 'C'),
(47, 5, 'Which two elementary particles are described as &lt;massless&gt; ?', 'Photon and gluon', 'Muon and neutrino', 'Electron and proton', 'A'),
(48, 5, 'Which of these phenomena inspired Albert Einstein in his development of general\nrelativity?', 'Watching two trains move in opposite directions', 'Watching a man fall off a roof', 'The\nvibration of strings on a violin', 'B'),
(49, 5, 'Does time always go forward?', 'Always', 'No', 'In theory...yes', 'C'),
(50, 5, 'What is hydrostatics?', 'Quantity of mass enclosed in a volume', 'Pressure of liquids to all\ndirections', 'Body of mass growing in a form', 'B'),
(51, 7, 'Originating in the Middle East, falafel is one of everyones favorite street foods. What is the\nmain ingredient of falafel?', 'Sesame seeds', 'Flour', 'Chickpeas', 'C'),
(52, 7, 'Arepas are corn cakes often filled with ingredients such as cheese, vegetables and meat.\nWhich 2 countries claim to have invented this delicious dish?', 'Colombia and Venezuela', 'Venezuela and Argentina', 'Chile and Colombia', 'A'),
(53, 7, 'The most popular street food in Peru, and culinary export success, is undoubtedly the\nceviche. In this dish, raw fish is cured by adding what ingredient to it?', 'Vinegar', 'Citrus juices', 'Hot\noil', 'B'),
(54, 7, 'In which country is it considered impolite to eat while walking (with some exceptions)?', 'Italy', 'China', 'Japan', 'C'),
(55, 7, 'In Italy, arancini are fried meatballs from what?', 'Spaghetti', 'Risotto', 'Olives', 'B'),
(56, 7, 'In which country is it considered impolite to eat while walking (with some exceptions)?', 'Italy', 'China', 'Japan', 'C'),
(57, 7, 'A good mate is prepared with water...', 'At 80 degrees', 'Boiling', 'Warm', 'A'),
(58, 7, 'What other country disputes us the invention of the Argentine dulce de leche?', 'Chile', 'Brazil', 'Uruguay', 'C'),
(59, 7, 'A Milanese with ham, cheese and tomato sauce is called...', 'Sicilian Milanese', 'Neapolitan\nMilanese', 'Maradonian Milanese', 'B'),
(60, 7, 'What are the most common ingredients of every meat patty?', 'Minced meat, eggs, onions\nand olives', 'Minced meat, eggs, tomato and olives', 'Minced meat, eggs, grape and corn', 'A');

-- --------------------------------------------------------

--
-- Структура таблицы `temas`
--

CREATE TABLE `temas` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `temas`
--

INSERT INTO `temas` (`id`, `nombre`) VALUES
(1, 'dasturlash'),
(2, 'Tarix'),
(3, 'Biologiya'),
(4, 'Sport'),
(5, 'Fizika'),
(6, 'inglizcha'),
(7, 'oziq-ovqat');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `estadisticas`
--
ALTER TABLE `estadisticas`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `estadisticas`
--
ALTER TABLE `estadisticas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
